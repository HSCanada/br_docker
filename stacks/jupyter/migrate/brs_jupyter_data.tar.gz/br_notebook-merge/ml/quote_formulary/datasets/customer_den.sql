
SET NOCOUNT ON;

SELECT        
-- top 10 
	ShipTo,
	BillTo,
	CustGrpWrk,
	MarketClass,
	Specialty,
	PracticeType,
	PracticeName,
	PostalCode,
	PhoneNo,
	City,
	Province,
	VPA,
	TerritoryCd,
	DateAccountOpened,
	Est12MoMerch,
	Est12MoTotal
FROM            BRS_Customer
WHERE        (AccountType <> 'D') AND (SalesDivision = 'AAD') AND Country = 'CA'